<body>

    <!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index.php"><img class="main-logo" src="../wfs_tmp/img/logo/logo.png" alt="" /></a>
                <strong><a href="index.php"><img src="../wfs_tmp/img/logo/logosn.png" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        
                        <li>
                            <a href="index.php"><i class="fa fa-home"></i> &nbsp;Home</a>
                        </li>
						
						<li>
                           <a href="h_view.php"><i class="fa fa-list"></i> &nbsp;Hospital Details</a>
                        </li>
						
						<li>
                            <a href="d_view.php"><i class="fa fa-list"></i> &nbsp;Doctor Details</a>
                        </li>


                           <li>
                            <a href="p_view.php"><i class="fa fa-list"></i> &nbsp;Patient Details</a>
                        </li>
						<li>
                            <a href="ps_view.php"><i class="fa fa-list"></i> &nbsp; prisciption Details</a>
                        </li>
						
                        <li>
                            <a class="has-arrow" href="#"><i class="fa fa-cog"></i> &nbsp;Settings</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a href="#"><i class="fa fa-key"></i> &nbsp;Change Password</a></li>
                                <li><a href="#"><i class="fa fa-lock"></i> &nbsp;Logout</a></li>
                            </ul>
                        </li>
                        
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- End Left menu area -->