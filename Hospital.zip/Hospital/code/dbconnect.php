<?php
if(!$con=mysqli_connect('localhost','root','','hospital_db'))
{
echo'<front color="red" size="6">Error While Connecting to Database</front>';
}
?>