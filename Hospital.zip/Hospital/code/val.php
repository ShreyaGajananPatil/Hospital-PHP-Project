<!-- Validation code Start-->
 
<link rel="stylesheet" href="../wfs_tmp/validation/validationEngine.jquery.css" type="text/css" media="screen" title="no title" charset="utf-8" />
<script src="../wfs_tmp/validation/jquery.min.js" type="text/javascript"></script>
<script src="../wfs_tmp/validation/jquery.validationEngine-en.js" type="text/javascript"></script>
<script src="../wfs_tmp/validation/jquery.validationEngine.js" type="text/javascript"></script>
		
 <script>	
   $(document).ready(function() {
   $("#WFS_Riz").validationEngine()
   });
 </script>

<!--End-->