 <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Copyright � <?php echo date('Y'); ?>. All rights reserved. Powered by <a href="#">WFS</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jquery
		============================================ -->
    <!-- <script src="../wfs_tmp/js/vendor/jquery-1.12.4.min.js"></script> -->
    <!-- bootstrap JS
		============================================ -->
    <script src="../wfs_tmp/js/bootstrap.min.js"></script>
    <!-- wow JS
		============================================ -->
    <script src="../wfs_tmp/js/wow.min.js"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="../wfs_tmp/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="../wfs_tmp/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="../wfs_tmp/js/owl.carousel.min.js"></script>
    <!-- sticky JS
		============================================ -->
    <script src="../wfs_tmp/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="../wfs_tmp/js/jquery.scrollUp.min.js"></script>
    <!-- counterup JS
		============================================ -->
    <script src="../wfs_tmp/js/counterup/jquery.counterup.min.js"></script>
    <script src="../wfs_tmp/js/counterup/waypoints.min.js"></script>
    <script src="../wfs_tmp/js/counterup/counterup-active.js"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="../wfs_tmp/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../wfs_tmp/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="../wfs_tmp/js/metisMenu/metisMenu.min.js"></script>
    <script src="../wfs_tmp/js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="../wfs_tmp/js/morrisjs/raphael-min.js"></script>
    <script src="../wfs_tmp/js/morrisjs/morris.js"></script>
    <script src="../wfs_tmp/js/morrisjs/morris-active.js"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="../wfs_tmp/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="../wfs_tmp/js/sparkline/jquery.charts-sparkline.js"></script>
    <script src="../wfs_tmp/js/sparkline/sparkline-active.js"></script>
    <!-- calendar JS
		============================================ -->
    <script src="../wfs_tmp/js/calendar/moment.min.js"></script>
    <script src="../wfs_tmp/js/calendar/fullcalendar.min.js"></script>
    <script src="../wfs_tmp/js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
		============================================ -->
    <script src="../wfs_tmp/js/plugins.js"></script>
    <!-- main JS
		============================================ -->
    <script src="../wfs_tmp/js/main.js"></script>
    <!-- tawk chat JS
		============================================ -->
    <script src="../wfs_tmp/js/tawk-chat.js"></script>
</body>

</html>