<script>
history.back();
</script>